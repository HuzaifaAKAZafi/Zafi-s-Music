# Build the APK

## Easiest: GitHub (no Android Studio needed)
1. Create a GitHub repo and upload this whole folder.
2. Go to Actions > "Build Android APK" > Run workflow.
3. After ~5 min download `ZafisMusic-APK` > ZafisMusic.apk and install on your phone.

## Locally
npm install
npm run build
npx cap add android
npx cap sync android
cd android && ./gradlew assembleRelease
(APK: android/app/build/outputs/apk/debug/ZafisMusic.apk)
