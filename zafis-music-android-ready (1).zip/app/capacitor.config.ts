import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.zafi.music',
  appName: "Zafi's Music",
  webDir: 'dist',
  android: { allowMixedContent: true },
  server: { androidScheme: 'https' }
};

export default config;
