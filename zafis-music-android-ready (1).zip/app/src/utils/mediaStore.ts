// IndexedDB store so imported local songs/videos survive app restarts
// (blob: URLs die on reload, so we keep the actual files here).
const DB_NAME = 'zafi_media';
const STORE = 'files';

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function saveMediaFile(id: string, file: Blob): Promise<void> {
  try {
    const db = await openDb();
    await new Promise<void>((res, rej) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).put(file, id);
      tx.oncomplete = () => res();
      tx.onerror = () => rej(tx.error);
    });
  } catch (e) {
    console.warn('saveMediaFile failed', e);
  }
}

export async function getMediaFile(id: string): Promise<Blob | null> {
  try {
    const db = await openDb();
    return await new Promise((res, rej) => {
      const req = db.transaction(STORE).objectStore(STORE).get(id);
      req.onsuccess = () => res((req.result as Blob) || null);
      req.onerror = () => rej(req.error);
    });
  } catch {
    return null;
  }
}

export async function deleteMediaFile(id: string): Promise<void> {
  try {
    const db = await openDb();
    await new Promise<void>((res, rej) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).delete(id);
      tx.oncomplete = () => res();
      tx.onerror = () => rej(tx.error);
    });
  } catch (e) {
    console.warn('deleteMediaFile failed', e);
  }
}
